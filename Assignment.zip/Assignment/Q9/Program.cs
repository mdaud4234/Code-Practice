﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q9
{
    class a
    {
        public void display()
        {
            System.Console.WriteLine("hahahaha");
        }
    }
    class b : a //b is child of a
    {
        public void display1()
        {
            System.Console.WriteLine("hihihih");
        }
    }
    class c
    {
        public static void Main()
        {
            b x = new b();
            x.display();
            x.display1();
        }
    }
}
