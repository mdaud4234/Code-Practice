﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int n, i = 0;
            Console.WriteLine("Enter a Value: ");
            n = int.Parse(Console.ReadLine());
            while (n > 0)
            {
                i++;
                n = n / 10;
            }
            Console.WriteLine("Number of digits: " + i);
        }
    }
}
