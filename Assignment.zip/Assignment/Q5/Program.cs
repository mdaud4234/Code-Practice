﻿using System;

namespace Q5
{
    class Program
    {
        static void Main(string[] args)  
        {
            Console.WriteLine("New Delhi");
            print();  

            mtest.Main();  
        }

        static public void print()
        {
            Console.WriteLine("New York");
        }

        class mtest
        {
            public static void Main()
            {
                mdelegate m1 = new mdelegate(dm.display);
                mdelegate m2 = new mdelegate(dm.print);
                mdelegate m3 = m1 + m2;
                mdelegate m4 = m2 + m1;
                m3();
                m4();
            }
        }
    }
}
